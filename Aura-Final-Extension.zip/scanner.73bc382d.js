var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,r,a,o,n){var i="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},l="function"==typeof i[o]&&i[o],s=l.cache||{},c="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function u(e,r){if(!s[e]){if(!t[e]){var a="function"==typeof i[o]&&i[o];if(!r&&a)return a(e,!0);if(l)return l(e,!0);if(c&&"string"==typeof e)return c(e);var n=Error("Cannot find module '"+e+"'");throw n.code="MODULE_NOT_FOUND",n}p.resolve=function(r){var a=t[e][1][r];return null!=a?a:r},p.cache={};var d=s[e]=new u.Module(e);t[e][0].call(d.exports,p,d,d.exports,this)}return s[e].exports;function p(e){var t=p.resolve(e);return!1===t?{}:u(t)}}u.isParcelRequire=!0,u.Module=function(e){this.id=e,this.bundle=u,this.exports={}},u.modules=t,u.cache=s,u.parent=l,u.register=function(e,r){t[e]=[function(e,t){t.exports=r},{}]},Object.defineProperty(u,"root",{get:function(){return i[o]}}),i[o]=u;for(var d=0;d<r.length;d++)u(r[d]);if(a){var p=u(a);"object"==typeof exports&&"undefined"!=typeof module?module.exports=p:"function"==typeof e&&e.amd?e(function(){return p}):n&&(this[n]=p)}}({iZYYG:[function(e,t,r){var a=e("@parcel/transformer-js/src/esmodule-helpers.js");a.defineInteropFlag(r),a.export(r,"config",()=>l);var o=e("~/lib/ethos-client"),n=e("~/lib/constants"),i=e("~/lib/crypto");let l={matches:["<all_urls>"],run_at:"document_idle"},s={ethAddress:/0x[a-fA-F0-9]{40}/g,baseName:/\b[a-zA-Z0-9][a-zA-Z0-9-]{0,}\.base\.eth\b/gi,ensName:/\b[a-zA-Z0-9][a-zA-Z0-9-]{2,}\.eth\b/gi},c=new WeakSet,u=new Map,d=new Map,p=null,f=null,g=!1,m=!1,y=null,x=null,h=null;async function v(){try{let e=await chrome.storage.local.get(["vaultSession"]);if(e.vaultSession){let{key:t,expiresAt:r}=e.vaultSession;Date.now()<r?(x=t,console.log("[Aura] Vault session loaded, expires in",Math.round((r-Date.now())/6e4),"minutes")):(x=null,await chrome.storage.local.remove(["vaultSession"]),console.log("[Aura] Vault session expired, cleared"))}else x=null}catch(e){console.log("[Aura] Could not load vault session:",e)}}async function b(e){if(!x)return"";try{let t=(0,i.getNoteKey)(e),r=await chrome.storage.sync.get([t]);if(r[t])return await (0,i.decrypt)(r[t],x)}catch(e){console.log("[Aura] Could not load note:",e)}return""}async function w(e,t){if(!x)return!1;try{let r=(0,i.getNoteKey)(e);if(t.trim()){let e=await (0,i.encrypt)(t,x);await chrome.storage.sync.set({[r]:e})}else await chrome.storage.sync.remove([r]);return!0}catch(e){return console.log("[Aura] Could not save note:",e),!1}}function E(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}async function A(e){try{console.log(`[Aura] Requesting background resolution for: ${e}`);let t=await chrome.runtime.sendMessage({type:"RESOLVE_NAME",name:e});if(t?.address)return console.log(`[Aura] Background resolved ${e} -> ${t.address}`),t.address}catch(t){console.error(`[Aura] Resolution messaging failed for ${e}:`,t)}return null}async function C(e,t,r,a,o){let n=e.value;if(!n){t&&(t.textContent="Enter password");return}try{let e=await chrome.storage.sync.get([i.VAULT_KEYS.VALIDATOR]);if(e[i.VAULT_KEYS.VALIDATOR]){let r=await (0,i.verifyPassword)(e[i.VAULT_KEYS.VALIDATOR],n);r?(x=n,await chrome.storage.local.set({vaultSession:{key:n,expiresAt:Date.now()+36e5}}),console.log("[Aura] Vault unlocked from hover, session stored"),g=!0,m=!0,y&&(clearTimeout(y),y=null),await T(a,o)):t&&(t.textContent="Wrong password")}else t&&(t.textContent="No vault set up")}catch(e){console.error("[Aura] Vault unlock failed:",e),t&&(t.textContent="Error unlocking")}}async function T(e,t){if(console.log("[Aura] showTooltip called with data:",JSON.stringify(t)),!p)return;let r=p.shadowRoot;if(!r)return;let a=r.querySelector(".aura-tooltip-container"),o=r.querySelector(".aura-tooltip");if(!a||!o)return;let l=e.getBoundingClientRect(),s=window.innerWidth,c=(0,n.getScoreColor)(t.score);o.style.setProperty("--aura-primary",c);let u=(0,n.SCORE_TIERS).find(e=>e.name===t.tier),d=u?u.label:"UNSCORED",f=null!==t.score?t.score:"\u2014",m=null!==t.score?t.score:0,v=2*Math.PI*26,A=t.resolvedAddress||t.identifier,T=t.ethosName||(t.identifier.length>20?t.identifier.slice(0,10)+"..."+t.identifier.slice(-8):t.identifier),S=E(T),L=t.ethosName?t.identifier.length>20?t.identifier.slice(0,10)+"..."+t.identifier.slice(-8):t.identifier:null,k=L?E(L):null,$=t.avatarUrl&&/^https?:\/\//i.test(t.avatarUrl)?E(t.avatarUrl):null,R=E(t.identifier),N=$?`<img src="${$}" class="aura-avatar" onerror="this.style.display='none';this.parentElement.innerHTML='<div class=\\'aura-score-text\\'><div class=\\'aura-score-val\\'>${f}</div><div class=\\'aura-tier-label-small\\'>${d}</div></div>';"/>`:`<div class="aura-score-text">
         <div class="aura-score-val">${f}</div>
         <div class="aura-tier-label-small">${d}</div>
       </div>`,O=$?`${f} \u2022 ${d}`:d,F=!!x,D=!1;try{let e=await chrome.storage.sync.get([i.VAULT_KEYS.VALIDATOR]);D=!!e[i.VAULT_KEYS.VALIDATOR]}catch(e){console.log("[Aura] Could not check vault setup status")}if(o.innerHTML=`
    <div class="aura-header">
      <div class="aura-ring-container">
        <svg class="aura-ring-svg" viewBox="0 0 56 56">
          <circle class="aura-ring-circle" cx="28" cy="28" r="26"></circle>
          <circle class="aura-ring-value" cx="28" cy="28" r="26"
            stroke-dasharray="${v}"
            stroke-dashoffset="${v-Math.min(100,Math.max(0,m/24))/100*v}">
          </circle>
        </svg>
        ${N}
      </div>
      <div class="aura-content">
        <div class="aura-title" title="${R}">${S}</div>
        ${k?`<div class="aura-subtitle" title="${R}">${k}</div>`:""}
        <div class="aura-badge">${O}</div>
      </div>
    </div>
    ${F?`
    <div class="aura-note-section" data-address="${E(A)}">
      <textarea class="aura-note-input" placeholder="Quick note..." rows="2"></textarea>
      <div class="aura-note-status"></div>
    </div>
    `:`
    <div class="aura-vault-unlock" data-address="${E(A)}">
      ${D?`
      <div class="aura-vault-header">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
        </svg>
        <span>Unlock to add note</span>
      </div>
      <div class="aura-vault-form">
        <input type="password" class="aura-vault-password" placeholder="Password" />
        <button class="aura-vault-unlock-btn" title="Unlock">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>
          </svg>
        </button>
      </div>
      <div class="aura-vault-error"></div>
      `:`
      <div class="aura-vault-setup-prompt">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/>
        </svg>
        <span>Create vault in extension to add notes</span>
      </div>
      `}
    </div>
    `}
    <div class="aura-divider"></div>
    <div class="aura-action">
      <a class="aura-button" href="https://app.ethos.network/profile/${encodeURIComponent(t.resolvedAddress||t.identifier)}" target="_blank" rel="noopener">
        View on Ethos
      </a>
    </div>
  `,F){let e=o.querySelector(".aura-note-section"),t=o.querySelector(".aura-note-input"),r=o.querySelector(".aura-note-status");if(e&&t&&r){let a=e.dataset.address||"";b(a).then(e=>{t.value=e}),t.addEventListener("input",()=>{r.textContent="",h&&clearTimeout(h),h=setTimeout(async()=>{r.textContent="Saving...";let e=await w(a,t.value);r.textContent=e?"Saved":"Error",setTimeout(()=>{r.textContent=""},1500)},800)}),t.addEventListener("focus",()=>{g=!0,y&&(clearTimeout(y),y=null)})}}else{let r=o.querySelector(".aura-vault-unlock"),a=o.querySelector(".aura-vault-password"),n=o.querySelector(".aura-vault-unlock-btn"),i=o.querySelector(".aura-vault-error");a&&(a.addEventListener("focus",()=>{g=!0,y&&(clearTimeout(y),y=null)}),a.addEventListener("keydown",async o=>{"Enter"===o.key&&await C(a,i,r,e,t)})),n&&a&&n.addEventListener("click",async o=>{o.preventDefault(),o.stopPropagation(),await C(a,i,r,e,t)})}let U=l.left+l.width/2-160-24,_=l.top-160-48;U+320+48>s-10&&(U=s-320-48-10),U<10&&(U=10),_<10&&(_=l.bottom-24+8),a.style.transform=`translate(${U}px, ${_}px)`,o.classList.add("visible")}function S(){if(!p)return;let e=p.shadowRoot;if(!e)return;let t=e.querySelector(".aura-tooltip-container"),r=e.querySelector(".aura-tooltip");r&&r.classList.remove("visible"),t&&setTimeout(()=>{r&&!r.classList.contains("visible")&&(t.style.transform="translate(-9999px, -9999px)")},200)}let L=[],k=null;async function $(){if(0===L.length)return;let e=L.splice(0,30);for(let t of(console.log(`[Aura] Scoring ${e.length} identifiers`),e)){let e=t.identifier.toLowerCase(),r=t.identifier;if("ens"===t.type||"base"===t.type){console.log(`[Aura] Resolving name: ${t.identifier} (type: ${t.type})`);let a=await A(t.identifier);if(a){r=a;let o=u.get(e);o&&(o.resolvedAddress=a),console.log(`[Aura] \u2713 Resolved ${t.identifier} \u2192 ${a}`)}else{console.log(`[Aura] \u2717 Failed to resolve ${t.identifier}`),R(e,null);continue}}try{console.log(`[Aura] Fetching score for address: ${r}`);let t=await (0,o.getScoreByAddress)(r);console.log(`[Aura] Score API response for ${e}:`,JSON.stringify(t));let a=t?.score??null;console.log(`[Aura] Extracted score value: ${a}`),R(e,a);let i=await (0,o.getUserByAddress)(r);if(i){let t=u.get(e);if(t&&(t.ethosName=i.displayName||i.username||void 0,t.avatarUrl=i.avatarUrl||void 0,console.log(`[Aura] Updated profile data for ${e}: name=${t.ethosName}, score=${t.score}`),null===t.score&&void 0!==i.score)){console.log(`[Aura] Using fallback score from user profile: ${i.score}`),t.score=i.score,t.tier=n.getTierForScore(i.score)?.name||"unscored";let r=d.get(e)||[];for(let e of r)e.className=`aura-target ${t.tier}`}}}catch(t){console.error(`[Aura] Score fetch failed for ${r}:`,t),R(e,null)}}L.length>0&&(k=setTimeout($,150))}function R(e,t){let r=e.toLowerCase(),a=(0,n.getTierForScore)(t),o=a?a.name:"unscored",i=u.get(r);i&&(i.score=t,i.tier=o,i.fetched=!0);let l=d.get(r)||[];for(let e of l)e.className=`aura-target ${o}`;f?.identifier===r&&i&&i.fetched&&T(f.element,i)}function N(e){let t;if(c.has(e))return;let r=e.textContent||"";if(!r.trim())return;let a=e.parentNode;if(!a)return;let o=a.tagName?.toLowerCase();if(["script","style","textarea","input","noscript"].includes(o)||a.classList?.contains("aura-target")||a.isContentEditable)return;let n=[],i=RegExp(s.ethAddress.source,"g");for(;null!==(t=i.exec(r));)n.push({text:t[0],index:t.index,type:"eth"});let l=RegExp(s.baseName.source,"gi");for(;null!==(t=l.exec(r));)n.push({text:t[0],index:t.index,type:"base"});let x=RegExp(s.ensName.source,"gi");for(;null!==(t=x.exec(r));){if(t[0].endsWith(".base.eth"))continue;let e=n.some(e=>t.index>=e.index&&t.index<e.index+e.text.length||e.index>=t.index&&e.index<t.index+t[0].length);e||n.push({text:t[0],index:t.index,type:"ens"})}if(0===n.length)return;c.add(e),n.sort((e,t)=>t.index-e.index);let h=r,v=[];for(let e of n){let t=h.slice(e.index+e.text.length);t&&v.unshift(document.createTextNode(t));let r=function(e,t){let r=document.createElement("span");return r.className="aura-target unscored",r.dataset.auraId=e.toLowerCase(),r.dataset.auraType=t,r.textContent=e,r.addEventListener("mouseenter",()=>{m=!0,y&&(clearTimeout(y),y=null);let t=e.toLowerCase();f={element:r,identifier:t};let a=u.get(t);console.log(`[Aura] Hover on ${t}, current data:`,a?JSON.stringify(a):"null"),a&&a.fetched?T(r,a):(function(e,t){if(!p)return;let r=p.shadowRoot;if(!r)return;let a=r.querySelector(".aura-tooltip-container"),o=r.querySelector(".aura-tooltip");if(!a||!o)return;o.style.setProperty("--aura-primary","#e4e4e7");let n=t.length>20?t.slice(0,10)+"..."+t.slice(-6):t;o.innerHTML=`
    <div class="aura-header">
      <div class="aura-ring-container">
        <svg class="aura-ring-svg" viewBox="0 0 56 56">
          <circle class="aura-ring-circle" cx="28" cy="28" r="26" style="opacity: 0.3"></circle>
          <circle class="aura-ring-value" cx="28" cy="28" r="26" 
            stroke-dasharray="163.36" 
            stroke-dashoffset="120"
            style="animation: spin 1s linear infinite; transform-origin: center;">
          </circle>
        </svg>
      </div>
      <div class="aura-content">
        <div class="aura-subtitle" style="margin-bottom: 2px;">Resolving...</div>
        <div class="aura-title" style="opacity: 0.7;">${n}</div>
      </div>
    </div>
  `;let i=e.getBoundingClientRect(),l=i.left-24,s=i.top-120;if(s<0&&(s=i.bottom-24),a.style.transform=`translate(${l}px, ${s}px)`,o.classList.add("visible"),!r.querySelector("#aura-spin-style")){let e=document.createElement("style");e.id="aura-spin-style",e.textContent="@keyframes spin { 100% { transform: rotate(360deg); } }",r.appendChild(e)}}(r,e),$())}),r.addEventListener("mouseleave",()=>{m=!1,y&&clearTimeout(y),y=setTimeout(()=>{g||m||(S(),f=null),y=null},200)}),r}(e.text,e.type);v.unshift(r);let a=e.text.toLowerCase();d.has(a)||d.set(a,[]),d.get(a).push(r),u.has(a)||u.set(a,{identifier:e.text,type:e.type,score:null,tier:"unscored"}),function(e,t){let r=e.toLowerCase();L.some(e=>e.identifier.toLowerCase()===r)||(L.push({identifier:e,type:t}),k&&clearTimeout(k),k=setTimeout($,150))}(e.text,e.type),h=h.slice(0,e.index)}h&&v.unshift(document.createTextNode(h));let b=document.createDocumentFragment();v.forEach(e=>b.appendChild(e)),a.replaceChild(b,e)}function O(e=document.body){let t;let r=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode:e=>{if(!e.textContent?.trim())return NodeFilter.FILTER_REJECT;let t=e.parentElement;if(!t)return NodeFilter.FILTER_REJECT;let r=t.tagName?.toLowerCase();return["script","style","noscript","textarea","input"].includes(r)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),a=[];for(;t=r.nextNode();)a.push(t);let o=0;!function e(){let t=Math.min(o+50,a.length);for(let e=o;e<t;e++)N(a[e]);(o=t)<a.length&&requestAnimationFrame(e)}()}let F=null,D=[];function U(){let e=[...D];for(let[e,t]of(D.length=0,F=null,d.entries())){let r=t.filter(e=>document.body.contains(e));0===r.length?(d.delete(e),u.delete(e)):r.length!==t.length&&d.set(e,r)}if(d.size>500){let e=Array.from(d.keys()),t=e.slice(0,d.size-500);for(let e of t)d.delete(e),u.delete(e)}for(let t of e)t.nodeType===Node.TEXT_NODE?N(t):t.nodeType===Node.ELEMENT_NODE&&O(t)}async function _(){console.log("[Aura] Initializing v6 scanner with global overlay..."),await v(),function(){if(document.getElementById("aura-target-styles"))return;let e=document.createElement("style");e.id="aura-target-styles";let t=(0,n.SCORE_TIERS).map(e=>`
    .aura-target.${e.name}::after { border: 1px solid ${e.color}66; }
    .aura-target.${e.name}:hover { background-color: ${e.color}1A; }
  `).join("\n");e.textContent=`
    .aura-target {
      position: relative;
      cursor: pointer;
      border-radius: 3px;
      transition: background-color 0.15s ease;
    }
    
    .aura-target::after {
      content: '';
      position: absolute;
      inset: -1px -2px;
      border-radius: 4px;
      pointer-events: none;
      opacity: 0;
      transition: opacity 0.15s ease;
    }
    
    .aura-target:hover::after {
      opacity: 1;
    }
    
    .aura-target.unscored::after { border: 1px dashed ${n.UNSCORED_COLOR}66; }
    .aura-target.unscored:hover { background-color: ${n.UNSCORED_COLOR}1A; }
    
    ${t}
    
    body.aura-xray-active *:not(.aura-target):not(script):not(style) {
      opacity: 0.15 !important;
      filter: grayscale(100%) !important;
    }
    body.aura-xray-active .aura-target {
      opacity: 1 !important;
      filter: none !important;
      position: relative;
      z-index: 1000;
    }
  `,document.head.appendChild(e)}(),function(){if(p)return;let e=document.createElement("div");e.id="aura-global-overlay";let t=e.attachShadow({mode:"open"}),r=document.createElement("style");r.textContent=`
    :host {
      all: initial;
      display: block;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 2147483647;
      pointer-events: none;
      
      --md-sys-color-surface: #1b1b1f;
      --md-sys-color-surface-container: #202125;
      --md-sys-color-on-surface: #e3e2e6;
      --md-sys-color-on-surface-variant: #c4c6d0;
      --md-sys-shape-corner: 16px;
      --md-sys-elevation-3: 0px 1px 3px 0px rgba(0, 0, 0, 0.3), 0px 4px 8px 3px rgba(0, 0, 0, 0.15);
      
      --aura-primary: #ffffff;
      --aura-primary-10: rgba(255, 255, 255, 0.1);
      --aura-primary-20: rgba(255, 255, 255, 0.2);
      
      font-family: 'Roboto', 'Segoe UI', system-ui, -apple-system, sans-serif;
    }
    
    .aura-tooltip-container {
      position: absolute;
      pointer-events: auto;
      padding: 24px;
      transition: transform 0.2s cubic-bezier(0.2, 0.0, 0, 1.0);
    }
    
    .aura-tooltip {
      background: var(--md-sys-color-surface-container);
      color: var(--md-sys-color-on-surface);
      padding: 16px;
      border-radius: var(--md-sys-shape-corner);
      box-shadow: var(--md-sys-elevation-3);
      min-width: 280px;
      max-width: 320px;
      overflow: hidden;
      opacity: 0;
      transform: scale(0.9) translateY(10px);
      transform-origin: top center;
      transition: opacity 0.15s linear, transform 0.2s cubic-bezier(0.2, 0.0, 0, 1.0);
      display: flex;
      flex-direction: column;
      gap: 12px;
      border: 1px solid rgba(255,255,255,0.08);
      box-sizing: border-box;
    }
    
    .aura-tooltip.visible {
      opacity: 1;
      transform: scale(1) translateY(0);
    }
    
    .aura-header {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    
    .aura-ring-container {
      position: relative;
      width: 56px;
      height: 56px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .aura-ring-svg {
      width: 100%;
      height: 100%;
      transform: rotate(-90deg);
    }
    
    .aura-ring-circle {
      fill: none;
      stroke-width: 3;
      stroke: var(--aura-primary-20);
    }
    
    .aura-ring-value {
      fill: none;
      stroke-width: 3;
      stroke: var(--aura-primary);
      stroke-linecap: round;
      filter: drop-shadow(0 0 4px var(--aura-primary));
      transition: stroke-dashoffset 0.5s ease-out;
    }
    
    .aura-avatar {
      position: absolute;
      width: 44px;
      height: 44px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid var(--aura-primary);
    }
    
    .aura-score-text {
      position: absolute;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      line-height: 1;
    }
    
    .aura-score-val {
      font-size: 16px;
      font-weight: 700;
      color: var(--md-sys-color-on-surface);
    }
    
    .aura-tier-label-small {
      font-size: 8px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-top: 2px;
      color: var(--aura-primary);
    }
    
    .aura-content {
      flex: 1;
      min-width: 0;
    }
    
    .aura-title {
      font-size: 16px;
      font-weight: 500;
      color: var(--md-sys-color-on-surface);
      margin-bottom: 2px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .aura-subtitle {
      font-size: 12px;
      color: var(--md-sys-color-on-surface-variant);
      margin-bottom: 6px;
    }
    
    .aura-badge {
      display: inline-flex;
      align-items: center;
      padding: 4px 8px;
      border-radius: 8px;
      background: var(--aura-primary-10);
      color: var(--aura-primary);
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    
    .aura-note-section {
      display: flex;
      flex-direction: column;
      gap: 4px;
      width: 100%;
      box-sizing: border-box;
    }

    .aura-note-input {
      width: 100%;
      min-height: 48px;
      padding: 8px 10px;
      border-radius: 8px;
      border: 1px solid rgba(255,255,255,0.15);
      background: rgba(0,0,0,0.3);
      color: var(--md-sys-color-on-surface);
      font-size: 12px;
      font-family: inherit;
      resize: none;
      outline: none;
      transition: border-color 0.15s;
      box-sizing: border-box;
    }

    .aura-note-input:focus {
      border-color: #D0BCFF;
    }

    .aura-note-input::placeholder {
      color: rgba(255,255,255,0.4);
    }

    .aura-note-status {
      font-size: 10px;
      color: rgba(255,255,255,0.5);
      min-height: 14px;
      text-align: right;
    }

    .aura-vault-unlock {
      padding: 8px 0;
    }

    .aura-vault-header {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      color: rgba(255,255,255,0.6);
      margin-bottom: 8px;
    }

    .aura-vault-header svg {
      color: #F2B8B5;
    }

    .aura-vault-form {
      display: flex;
      gap: 6px;
    }

    .aura-vault-password {
      flex: 1;
      background: rgba(0,0,0,0.3);
      border: 1px solid rgba(255,255,255,0.15);
      border-radius: 6px;
      padding: 6px 10px;
      font-size: 11px;
      color: #E6E1E5;
      outline: none;
      transition: border-color 0.15s;
    }

    .aura-vault-password:focus {
      border-color: #D0BCFF;
    }

    .aura-vault-password::placeholder {
      color: rgba(255,255,255,0.4);
    }

    .aura-vault-unlock-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      border-radius: 6px;
      background: #D0BCFF;
      border: none;
      color: #381E72;
      cursor: pointer;
      transition: background 0.15s, transform 0.15s;
    }

    .aura-vault-unlock-btn:hover {
      background: #EADDFF;
      transform: scale(1.05);
    }

    .aura-vault-unlock-btn:active {
      transform: scale(0.95);
    }

    .aura-vault-error {
      font-size: 10px;
      color: #F2B8B5;
      min-height: 14px;
      margin-top: 4px;
    }

    .aura-vault-setup-prompt {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 11px;
      color: rgba(255,255,255,0.5);
      padding: 4px 0;
    }

    .aura-vault-setup-prompt svg {
      color: #939094;
    }

    .aura-divider {
      height: 1px;
      background: rgba(255,255,255,0.1);
      width: 100%;
    }

    .aura-action {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 8px;
    }

    .aura-note-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: rgba(208, 188, 255, 0.1);
      border: none;
      color: #D0BCFF;
      cursor: pointer;
      transition: background 0.15s, transform 0.15s;
    }

    .aura-note-btn:hover {
      background: rgba(208, 188, 255, 0.2);
      transform: scale(1.05);
    }

    .aura-note-btn:active {
      transform: scale(0.95);
    }

    .aura-button {
      background: none;
      border: none;
      color: var(--aura-primary);
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      padding: 8px 12px;
      border-radius: 20px;
      text-decoration: none;
      transition: background 0.15s;
    }

    .aura-button:hover {
      background: var(--aura-primary-10);
    }
  `,t.appendChild(r);let a=document.createElement("div");a.className="aura-tooltip-container";let o=document.createElement("div");o.className="aura-tooltip",a.appendChild(o),t.appendChild(a),a.addEventListener("mouseenter",()=>{g=!0,y&&(clearTimeout(y),y=null)}),a.addEventListener("mouseleave",()=>{g=!1,y&&clearTimeout(y),y=setTimeout(()=>{g||m||(S(),f=null),y=null},150)}),document.body.appendChild(e),p=e}(),O(),function(){let e=new MutationObserver(e=>{for(let t of e)for(let e of t.addedNodes)D.push(e);F&&clearTimeout(F),F=setTimeout(U,200)});e.observe(document.body,{childList:!0,subtree:!0}),chrome.runtime.onMessage.addListener(e=>{if("TOGGLE_XRAY"===e.type&&document.body.classList.toggle("aura-xray-active"),"VAULT_LOCKED"===e.type&&(console.log("[Aura] Vault locked - syncing state"),x=null,f)){let e=u.get(f.identifier);e&&T(f.element,e)}if("VAULT_UNLOCKED"===e.type&&e.sessionKey&&(console.log("[Aura] Vault unlocked - syncing state"),x=e.sessionKey,f)){let e=u.get(f.identifier);e&&T(f.element,e)}})}(),console.log("[Aura] Scanner ready. Vault session:",x?"active":"none")}"loading"===document.readyState?document.addEventListener("DOMContentLoaded",_):_()},{"~/lib/ethos-client":"avyHb","~/lib/constants":"j1SWx","~/lib/crypto":"7MSam","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],avyHb:[function(e,t,r){var a=e("@parcel/transformer-js/src/esmodule-helpers.js");a.defineInteropFlag(r),a.export(r,"getScoreByAddress",()=>c),a.export(r,"getUserByAddress",()=>u),a.export(r,"getUserByTwitter",()=>d),a.export(r,"clearCache",()=>p);let o=new Map,n={score:3e5,user:6e5};function i(e){let t=o.get(e);return t?Date.now()>t.expiresAt?(o.delete(e),null):t.data:null}function l(e,t,r){if(o.size>500){let e=Date.now();for(let[t,r]of o.entries())e>r.expiresAt&&o.delete(t);if(o.size>500){let e=Array.from(o.entries()).sort((e,t)=>e[1].expiresAt-t[1].expiresAt);for(let[t]of e.slice(0,o.size-500))o.delete(t)}}o.set(e,{data:t,expiresAt:Date.now()+r})}async function s(e){try{let t=await fetch(`https://api.ethos.network/api/v2${e}`,{method:"GET",headers:{"X-Ethos-Client":"aura-chrome-extension@1.0.0","Content-Type":"application/json"}});if(!t.ok){if(404===t.status)return{data:null,error:"not_found"};throw Error(`API error: ${t.status}`)}return{data:await t.json()}}catch(e){return console.error("[Aura] API request failed:",e),{data:null,error:String(e)}}}async function c(e){let t=`score:${e.toLowerCase()}`,r=i(t);if(r)return r;let a=await s(`/score/address?address=${e}`);return a.data&&!a.error?(l(t,a.data,n.score),a.data):null}async function u(e){let t=`user:address:${e.toLowerCase()}`,r=i(t);if(r)return r;let a=await s(`/user/by/address/${e}`);return a.data&&!a.error?(l(t,a.data,n.user),a.data):null}async function d(e){let t=`user:twitter:${e.toLowerCase()}`,r=i(t);if(r)return r;let a=await s(`/user/by/x/${e}`);return a.data&&!a.error?(l(t,a.data,n.user),a.data):null}function p(){o.clear()}},{"@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],fRZO2:[function(e,t,r){r.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},r.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},r.exportAll=function(e,t){return Object.keys(e).forEach(function(r){"default"===r||"__esModule"===r||t.hasOwnProperty(r)||Object.defineProperty(t,r,{enumerable:!0,get:function(){return e[r]}})}),t},r.export=function(e,t,r){Object.defineProperty(e,t,{enumerable:!0,get:r})}},{}],j1SWx:[function(e,t,r){var a=e("@parcel/transformer-js/src/esmodule-helpers.js");a.defineInteropFlag(r),a.export(r,"SCORE_TIERS",()=>o),a.export(r,"UNSCORED_COLOR",()=>n),a.export(r,"getTierForScore",()=>i),a.export(r,"getScoreColor",()=>l),a.export(r,"getScoreLabel",()=>s);let o=[{name:"untrusted",min:0,max:799,color:"#F2B8B5",label:"UNTRUSTED"},{name:"questionable",min:800,max:999,color:"#FFB4AB",label:"QUESTIONABLE"},{name:"neutral",min:1e3,max:1199,color:"#938F99",label:"NEUTRAL"},{name:"known",min:1200,max:1399,color:"#CCC2DC",label:"KNOWN"},{name:"established",min:1400,max:1599,color:"#D0BCFF",label:"ESTABLISHED"},{name:"reputable",min:1600,max:1799,color:"#B8C4FF",label:"REPUTABLE"},{name:"exemplary",min:1800,max:1999,color:"#7DD3FC",label:"EXEMPLARY"},{name:"distinguished",min:2e3,max:2199,color:"#4ADE80",label:"DISTINGUISHED"},{name:"revered",min:2200,max:2399,color:"#C084FC",label:"REVERED"},{name:"renowned",min:2400,max:1/0,color:"#A78BFA",label:"RENOWNED"}],n="#71717A";function i(e){return null===e?null:o.find(t=>e>=t.min&&e<=t.max)||o[0]}function l(e){let t=i(e);return t?t.color:n}function s(e){let t=i(e);return t?t.label:"UNSCORED"}},{"@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"7MSam":[function(e,t,r){var a=e("@parcel/transformer-js/src/esmodule-helpers.js");a.defineInteropFlag(r),a.export(r,"encrypt",()=>i),a.export(r,"decrypt",()=>l),a.export(r,"createValidator",()=>s),a.export(r,"verifyPassword",()=>c),a.export(r,"VAULT_KEYS",()=>u),a.export(r,"getNoteKey",()=>d);let o="AURA_VAULT_V1";async function n(e,t){let r=new TextEncoder,a=await crypto.subtle.importKey("raw",r.encode(e),"PBKDF2",!1,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt:t,iterations:1e5,hash:"SHA-256"},a,{name:"AES-GCM",length:256},!1,["encrypt","decrypt"])}async function i(e,t){let r=new TextEncoder,a=crypto.getRandomValues(new Uint8Array(16)),o=crypto.getRandomValues(new Uint8Array(12)),i=await n(t,a),l=await crypto.subtle.encrypt({name:"AES-GCM",iv:o},i,r.encode(e)),s=new Uint8Array(a.length+o.length+l.byteLength);return s.set(a,0),s.set(o,a.length),s.set(new Uint8Array(l),a.length+o.length),btoa(String.fromCharCode(...s))}async function l(e,t){let r=new TextDecoder,a=new Uint8Array(atob(e).split("").map(e=>e.charCodeAt(0))),o=a.slice(0,16),i=a.slice(16,28),l=a.slice(28),s=await n(t,o),c=await crypto.subtle.decrypt({name:"AES-GCM",iv:i},s,l);return r.decode(c)}async function s(e){return i(o,e)}async function c(e,t){try{let r=await l(e,t);return r===o}catch{return!1}}let u={VALIDATOR:"vault_validator",NOTE_PREFIX:"note_"};function d(e){return`${u.NOTE_PREFIX}${e.toLowerCase()}`}},{"@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}]},["iZYYG"],"iZYYG","parcelRequire3813"),globalThis.define=t;